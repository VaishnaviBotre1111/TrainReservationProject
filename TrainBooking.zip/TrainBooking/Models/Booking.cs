﻿using System;
using System.Collections.Generic;

namespace TrainBooking.Models;

public partial class Booking
{
    public int BookingId { get; set; }

    public int UserId { get; set; }

    public int TrainId { get; set; }

    public DateTime BookingDate { get; set; }

    public int SeatsBooked { get; set; }

    public virtual Train Train { get; set; } = null!;

    public virtual User User { get; set; } = null!;
}
