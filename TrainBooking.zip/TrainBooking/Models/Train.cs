﻿using System;
using System.Collections.Generic;

namespace TrainBooking.Models;

public partial class Train
{
    public int TrainId { get; set; }

    public string TrainName { get; set; } = null!;

    public string Source { get; set; } = null!;

    public string Destination { get; set; } = null!;

    public DateTime DepartureTime { get; set; }

    public DateTime ArrivalTime { get; set; }

    public int TotalSeats { get; set; }

    public virtual ICollection<Booking> Bookings { get; set; } = new List<Booking>();
}
